﻿using api.Data.Models.Locales;
using AutoMapper;

namespace api.Helpers
{
    public class AutoMapperLocal : Profile
    {
        
       

        public AutoMapperLocal()
        {

            //CreateMap<Local, LocalDTO>();
            //CreateMap<LocalDTO, Local>();
            //var user = (User)context.HttpContext.Items["User"];
            CreateMap<LocalDTO,Local>()
              .ForMember(dest => dest.Userid, source => source.MapFrom(_ =>1 ));
        }
    }
}
