﻿namespace api.Controllers;
using Microsoft.AspNetCore.Mvc;
using api.Authorization;
using api.Data.Models.Auth;
using api.Services;
using AutoMapper;
using api.Helpers;
using Microsoft.Extensions.Options;
using api.Data.Models.Locales;

[Authorize]
[ApiController]
[Route("[controller]")]
public class LocalesController : ControllerBase
{
    private ILocalService _localService;
    

    public LocalesController(
        ILocalService localService)
    {
        _localService = localService;

 
    }
    [AllowAnonymous]
    [HttpGet]
    public IActionResult GetAll()
    {
        var locals = _localService.GetAll();
        return Ok(locals);
    }
    [AllowAnonymous]
    [HttpGet("{id:int}")]
    public IActionResult GetById(int id)
    {
        /* only admins can access other user records
        var currentUser = (User)HttpContext.Items["User"];
        if (id != currentUser.Id && currentUser.Role != Role.User)
            return Unauthorized(new { message = "Unauthorized" });
        */
        var local = _localService.GetById(id);
        return Ok(local);
    }

    [Authorize(Role.User)]
    [HttpPost("registrar")]
    public IActionResult Register(LocalDTO model)
    {
        _localService.Register(model);
        return Ok(new { message = "Local registrado" });
    }

    [HttpPut("{id}")]
    public IActionResult Update(int id, LocalDTO model)
    {
        _localService.Update(id, model);
        return Ok(new { message = "Local Actualizado" });
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        _localService.Delete(id);
        return Ok(new { message = "Local elmininado" });
    }


}