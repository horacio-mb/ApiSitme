﻿namespace api.Data.Models.Auth
{
    public enum Role
    {
        Admin,
        Client,
        User
    }
}
