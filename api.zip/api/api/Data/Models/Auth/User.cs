﻿
using System.Text.Json.Serialization;
using api.Data.Models.Locales;

namespace api.Data.Models.Auth
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
       
        public string Correo { get; set; }
    
        public int Telefono { get; set; }
        public string Username { get; set; }
        public Role Role { get; set; }
        
        public List<Local> Locals { get; set; }
        [JsonIgnore]
        public string PasswordHash { get; set; }

        
    }
}
