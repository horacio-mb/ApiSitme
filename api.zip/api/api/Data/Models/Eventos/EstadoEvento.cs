﻿namespace api.Data.Models.Eventos
{
    public enum EstadoEvento
    {
        Agotado,
        Cerrado,
        Disponible
    }
}
