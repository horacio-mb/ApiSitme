﻿using api.Data.Models.Locales;

namespace api.Data.Models.Eventos
{
    public class Evento
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public DateOnly Fecha { get; set; }
        public TimeOnly HoraInicio { get; set; }
        public TimeOnly HoraFin { get; set; }
        public EstadoEvento Estado { get; set; }
        public int LocalId { get; set; }
        public Local Local { get; set; }

    }
}
