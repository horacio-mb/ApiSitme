﻿using api.Data.Models.Auth;
using api.Data.Models.Eventos;
using System.Text.Json.Serialization;

namespace api.Data.Models.Locales
{
    public class Local
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Descripcion { get; set; }
        public Estado Estado { get; set; }
        public int Userid { get; set; }

        public List<Evento> Eventos { get; set; }
        [JsonIgnore]
        public User User { get; set; }

    }
}
