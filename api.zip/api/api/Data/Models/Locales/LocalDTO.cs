﻿using System.ComponentModel.DataAnnotations;

namespace api.Data.Models.Locales
{
    public class LocalDTO
    {
        [Required]
        public string Nombre { get; set; }
        [Required]
        public string Direccion { get; set; }
        [Required]
        public string Descripcion { get; set; }
        [Required]
        public Estado Estado { get; set; }
        
       
        //[Required]
        //public User User { get; set; }
    }
}
