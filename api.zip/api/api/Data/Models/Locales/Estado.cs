﻿namespace api.Data.Models.Locales
{
    public enum Estado
    {
        Agotado,
        Cerrado,
        Disponible
    }
}
