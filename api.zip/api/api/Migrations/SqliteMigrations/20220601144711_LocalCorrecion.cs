﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace api.Migrations.SqliteMigrations
{
    public partial class LocalCorrecion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
