﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace api.Migrations.SqliteMigrations
{
    public partial class quitarcambio : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Locals_Users_UserId",
                table: "Locals");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Locals",
                newName: "Userid");

            migrationBuilder.RenameIndex(
                name: "IX_Locals_UserId",
                table: "Locals",
                newName: "IX_Locals_Userid");

            migrationBuilder.AddForeignKey(
                name: "FK_Locals_Users_Userid",
                table: "Locals",
                column: "Userid",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Locals_Users_Userid",
                table: "Locals");

            migrationBuilder.RenameColumn(
                name: "Userid",
                table: "Locals",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_Locals_Userid",
                table: "Locals",
                newName: "IX_Locals_UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Locals_Users_UserId",
                table: "Locals",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
