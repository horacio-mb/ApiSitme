﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace api.Migrations.SqliteMigrations
{
    public partial class quitarIdCliente : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "idCliente",
                table: "Locals");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "idCliente",
                table: "Locals",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }
    }
}
