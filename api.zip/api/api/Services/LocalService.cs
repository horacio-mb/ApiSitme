﻿using AutoMapper;
using BCrypt.Net;
using api.Authorization;

using api.Helpers;
using api.Data.Models.Locales;
using api.Data.Models.Auth;

namespace api.Services;
public interface ILocalService
{
    //AuthenticateResponse Authenticate(AuthenticateRequest model);
    IEnumerable<Local> GetAll();
    Local GetById(int id);
    void Register(LocalDTO model);
    void Update(int id, LocalDTO model);
    void Delete(int id);
}

public class LocalService : ILocalService
{
    private DataContext _context;
    private IJwtUtils _jwtUtils;
    private readonly IMapper _mapper;
    
    private readonly IHttpContextAccessor httpContext;
    private IUserService _userService;

    public LocalService(
        DataContext context,
        IJwtUtils jwtUtils,
        IMapper mapper,
        IHttpContextAccessor httpContext,
        IUserService userService)
    {
        _context = context;
        _jwtUtils = jwtUtils;
        _mapper = mapper;
        this.httpContext = httpContext;
        _userService = userService;
    }
    /*
        public Local Authenticate(Local model)
        {
            var local = _context.Locals.SingleOrDefault(x => x.id == model.id);

            // validate
            if (local == null || !BCrypt.Verify(model., user.PasswordHash))
                throw new AppException("Username or password is incorrect");

            // authentication successful
            var response = _mapper.Map<AuthenticateResponse>(user);
            response.Token = _jwtUtils.GenerateToken(user);
            return response;
        }*/

    public IEnumerable<Local> GetAll()
    {
        return _context.Locals;
    }

    public Local GetById(int id)
    {
        return getLocal(id);
    }

    public void Register(LocalDTO model)
    {
        // validate
        if (_context.Locals.Any(x => x.Nombre == model.Nombre))
            throw new AppException("Local '" + model.Nombre + "' Ya esta usado");

        // map model to new user object
        var local = _mapper.Map<Local>(model);
        //local.Estado = Estado.Disponible;
        var user = (User)httpContext.HttpContext.Items["User"];
        local.Userid = user.Id;

        // hash password
        //user.PasswordHash = BCrypt.HashPassword(model.Password);

        // save local
        _context.Locals.Add(local);
        _context.SaveChanges();
    }

    public void Update(int id, LocalDTO model)
    {
        var local = getLocal(id);
        var user = (User)httpContext.HttpContext.Items["User"];
        if (local.Userid!=user.Id)
            throw new AppException("No puede editar un local que no sea suyo");

        // validate
        if (model.Nombre != local.Nombre && _context.Locals.Any(x => x.Nombre == model.Nombre))
            throw new AppException("Nombre '" + model.Nombre + "' ya esta en uso");

        /*hash password if it was entered
        if (!string.IsNullOrEmpty(model.Password))
            local.PasswordHash = BCrypt.HashPassword(model.Password);

        */
        // copy model to user and save
        _mapper.Map(model, local);
        _context.Locals.Update(local);
        _context.SaveChanges();
    }

    public void Delete(int id)
    {
        var local = getLocal(id);
        var user = (User)httpContext.HttpContext.Items["User"];
        if (local.Userid != user.Id)
            throw new AppException("No puede elminiar un local que no sea suyo");
        else {
            _context.Locals.Remove(local);
            _context.SaveChanges(); }
        
    }

    // helper methods

    private Local getLocal(int id)
    {
        var local = _context.Locals.Find(id);
        if (local == null) throw new KeyNotFoundException("No se encontro Local");
        return local;
    }
}